<?php
$host="localhost";
$user="root";
$pswd="";
$dbname="form";
$conn = mysqli_connect($host, $user, $pswd, $dbname);


?>